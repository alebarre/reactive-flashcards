rootProject.name = "reactive-flashcards"
