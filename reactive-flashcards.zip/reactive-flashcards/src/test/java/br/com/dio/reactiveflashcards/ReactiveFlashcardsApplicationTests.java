package br.com.dio.reactiveflashcards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveFlashcardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
